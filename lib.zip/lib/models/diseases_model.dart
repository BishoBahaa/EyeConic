import 'package:flutter/material.dart';

class DiseasesModel {
  final String? name;
  final Color? color;


  DiseasesModel( {this.name, this.color, });
}

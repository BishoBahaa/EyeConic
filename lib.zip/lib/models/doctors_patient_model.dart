

class DoctorsPatientModel {
  final String pFirstName;
  final String pLastName;
  final String pImage;

  DoctorsPatientModel({
    required this.pFirstName,
    required this.pLastName,
    required this.pImage,
  });
}

import 'package:eye_diseases/models/doctors_patient_model.dart';
import 'package:eye_diseases/services/doctor_api.dart';
import 'package:eye_diseases/widgets/patient_item.dart';
import 'package:flutter/material.dart';

class PatientsListView extends StatefulWidget {
  const PatientsListView({super.key});

  @override
  State<PatientsListView> createState() => _PatientsListViewState();
}

class _PatientsListViewState extends State<PatientsListView> {
  // final List<DoctorsPatientModel> patientsList = [
  //   DoctorsPatientModel(
  //       pFirstName: 'Ashraf Khaled',
  //       pLastName: "",
  //       pImage: 'assets/images/eye-scan.png'),
  //   DoctorsPatientModel(
  //       pFirstName: 'Ashraf Khaled',
  //       pLastName: "",
  //       pImage: 'assets/images/eye-scan.png'),
  //   DoctorsPatientModel(
  //       pFirstName: 'Ashraf Khaled',
  //       pLastName: "",
  //       pImage: 'assets/images/eye-scan.png'),
  //   DoctorsPatientModel(
  //       pFirstName: 'Ashraf Khaled',
  //       pLastName: "",
  //       pImage: 'assets/images/eye-scan.png'),
  //   DoctorsPatientModel(
  //       pFirstName: 'Ashraf Khaled',
  //       pLastName: "",
  //       pImage: 'assets/images/eye-scan.png'),
  // ];


  List<DoctorsPatientModel> patient = [];

  @override
  void initState() {
    super.initState();
    getAllDoctors();
  }

  Future<void> getAllDoctors() async {
    patient = await DoctorApiService().getAllPatient();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.indigo,
          title: const Text(
            'Patients List',
            style: TextStyle(color: Colors.white),
          ),
          centerTitle: true,
        ),
        body: ListView.builder(
          physics: const BouncingScrollPhysics(),
          itemCount: patient.length,
          itemBuilder: (context, index) {
            return PatientItem(
              patientModel: patient[index],
            );
          },
        ));
  }
}

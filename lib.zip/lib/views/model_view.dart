import 'dart:convert';
import 'dart:io';
import 'dart:convert' as convert;
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;


class ModelView extends StatefulWidget {
  @override
  _ModelViewState createState() => _ModelViewState();
}

class _ModelViewState extends State<ModelView> {

  String body = "";
  String? disease;
  double? confidence;

  File? _imageFile;

  Future uploadeImage() async {
    final myfile = await ImagePicker().pickImage(source: ImageSource.gallery);
    setState(() {
      _imageFile = File(myfile!.path);
    });
  }

  Future Predict() async {
    if (_imageFile == null) return "";

    String base64 = base64Encode(_imageFile!.readAsBytesSync());

    Map<String, String> requestHeaders = {
      'Content-type': 'application/x-www-form-urlencoded',
    };
    var response = await http.post(
        Uri.parse(
            "https://classify.roboflow.com/theeyedismodel/1?api_key=HMVd15jfQhNSkA3Qm7to"),
        body: base64,
        headers: requestHeaders);

    var jsonResponse =
        convert.jsonDecode(response.body) as Map<String, dynamic>;
    // for (var element in body) {

    // }

    setState(() {
      if (jsonResponse['confidence'] >= 0.80) {
        disease = jsonResponse['top'];
        confidence = jsonResponse['confidence'] * 100;
      } else {
        disease = 'Not eye fundus';
        confidence = 100.0;
      }

      body = response.body;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Color(0xffd0d4fc), // Same as app bar background

        appBar: AppBar(
          backgroundColor: Color(0xff485190),
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(
              bottom: Radius.circular(16.0),
            ),
          ),
          elevation: 4,
          title: Text(
            'Eye-Conic 👁️',
            style:
                TextStyle(color: Colors.white, fontSize: 25),
          ),
          centerTitle: true,
        ),
        body: SafeArea(
          child: Container(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                    width: 250,
                    height: 250,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(16.0),
                      child: _imageFile != null
                          ? Image.file(_imageFile!)
                          
                          : Container(),
                    )),
                SizedBox(height: 20),
                disease != null ?
                Text(
                  "Disease: $disease",
                  style: TextStyle(fontSize: 20,color: Colors.black),
                ):Text(
                  "Disease:", style: TextStyle(fontSize: 20,color: Colors.black),),
                SizedBox(height: 20),
                confidence != null?
                Text(
                  "Confidence: $confidence",
                  style: TextStyle(fontSize: 20,color: Colors.black),
                ):Text(
                  "Confidence:", style: TextStyle(fontSize: 20,color: Colors.black),),
                SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                       style: ElevatedButton.styleFrom(
                          foregroundColor: Color.fromARGB(255, 0, 79, 119)),
                      onPressed: () {
                        uploadeImage();
                      },
                      child: Text('Upload Image'),
                    ),
                    SizedBox(width: 20),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          foregroundColor: Color.fromARGB(255, 0, 79, 119)),
                      onPressed: () {
                        Predict();
                      },
                      child: Text('Check'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
